# ShortTk DownlaodRealeses shell lib Copyright (c) Boubajoker 2021. All right reserved. Project under MIT License.

__version__ = "0.0.1 Alpha A-1"
__all__ = [
    "librairy",
    "shell",
    "librairy shell",
    "downlaod shell lib"
]